require('dotenv').config();
const path=require('path'),crypto=require('crypto'),express=require('express'),session=require('express-session'),PgStore=require('connect-pg-simple')(session),
 pg=require('pg'),bcrypt=require('bcrypt'),helmet=require('helmet'),rateLimit=require('express-rate-limit'),nodemailer=require('nodemailer'),passport=require('passport'),{Strategy:Google}=require('passport-google-oauth20');
if(!process.env.SESSION_SECRET||!process.env.DATABASE_URL){console.error('Set DATABASE_URL and SESSION_SECRET in .env');process.exit(1)}
pg.types.setTypeParser(1082,v=>v);pg.types.setTypeParser(1083,v=>v.slice(0,5));pg.types.setTypeParser(1700,Number);
const pool=new pg.Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.PGSSL==='true'?{rejectUnauthorized:false}:undefined});
const q=(s,p)=>pool.query(s,p),app=express(),prod=process.env.NODE_ENV==='production';
app.set('trust proxy',1);app.use(helmet({contentSecurityPolicy:false}),express.json({limit:'50kb'}));
app.use(session({store:new PgStore({pool,tableName:'session'}),secret:process.env.SESSION_SECRET,resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:prod,maxAge:7*864e5}}));
const api=express.Router(),auth=express.Router(),bad=(res,m,c=400)=>res.status(c).json({error:m});
const me=async id=>(await q('SELECT u.id,u.name,u.email,u.dark,COALESCE(g.hours,3) AS goal FROM users u LEFT JOIN study_goals g ON g.user_id=u.id WHERE u.id=$1',[id])).rows[0];
const login=(req,res,id,redirect)=>req.session.regenerate(async()=>{req.session.uid=id;redirect?res.redirect(process.env.APP_URL||'/'):res.json(await me(id))});
auth.use(rateLimit({windowMs:15*60*1000,limit:60,standardHeaders:true}));
auth.post('/signup',async(req,res)=>{try{const{name='',email='',password=''}=req.body,e=email.trim().toLowerCase();
 if(!name.trim()||!/^\S+@\S+\.\S+$/.test(e))return bad(res,'Please enter a valid name and email.');if(password.length<8)return bad(res,'Password must be at least 8 characters.');
 if((await q('SELECT 1 FROM users WHERE email=$1',[e])).rowCount)return bad(res,'An account with this email already exists.',409);
 const{rows:[u]}=await q('INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id',[name.trim().slice(0,60),e,await bcrypt.hash(password,12)]);
 await q('INSERT INTO study_goals(user_id) VALUES($1)',[u.id]);login(req,res,u.id)}catch(x){console.error(x);bad(res,'Could not create account.',500)}});
auth.post('/login',async(req,res)=>{try{const e=(req.body.email||'').trim().toLowerCase(),{rows:[u]}=await q('SELECT id,password_hash FROM users WHERE email=$1',[e]);
 if(!u||!u.password_hash||!await bcrypt.compare(req.body.password||'',u.password_hash))return bad(res,'Incorrect email or password.',401);login(req,res,u.id)}catch(x){bad(res,'Login failed.',500)}});
auth.post('/logout',(req,res)=>req.session.destroy(()=>{res.clearCookie('connect.sid');res.json({ok:true})}));
auth.get('/me',async(req,res)=>req.session.uid?res.json(await me(req.session.uid)):bad(res,'Not logged in',401));
auth.post('/forgot',async(req,res)=>{try{const e=(req.body.email||'').trim().toLowerCase(),{rows:[u]}=await q('SELECT id FROM users WHERE email=$1',[e]);
 if(u){const t=crypto.randomBytes(32).toString('hex');await q("INSERT INTO password_resets(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '1 hour')",[u.id,crypto.createHash('sha256').update(t).digest('hex')]);
  const link=`${process.env.APP_URL||''}/?reset=${t}`;
  if(process.env.SMTP_URL)await nodemailer.createTransport(process.env.SMTP_URL).sendMail({from:process.env.MAIL_FROM,to:e,subject:'Reset your StudyBloom password',text:`Reset your password (valid 1 hour): ${link}`});else console.log('Password reset link:',link)}
 res.json({ok:true})}catch(x){console.error(x);res.json({ok:true})}});
auth.post('/reset',async(req,res)=>{try{const{token='',password=''}=req.body;if(password.length<8)return bad(res,'Password must be at least 8 characters.');
 const h=crypto.createHash('sha256').update(token).digest('hex'),{rows:[r]}=await q('SELECT id,user_id FROM password_resets WHERE token_hash=$1 AND NOT used AND expires_at>now()',[h]);
 if(!r)return bad(res,'This reset link is invalid or has expired.');await q('UPDATE users SET password_hash=$1 WHERE id=$2',[await bcrypt.hash(password,12),r.user_id]);await q('UPDATE password_resets SET used=true WHERE id=$1',[r.id]);res.json({ok:true})}catch(x){bad(res,'Reset failed.',500)}});
if(process.env.GOOGLE_CLIENT_ID){passport.use(new Google({clientID:process.env.GOOGLE_CLIENT_ID,clientSecret:process.env.GOOGLE_CLIENT_SECRET,callbackURL:'/api/auth/google/callback'},async(_a,_r,p,done)=>{try{
 const em=p.emails?.[0]?.value?.toLowerCase();let{rows:[u]}=await q('SELECT id FROM users WHERE google_id=$1 OR email=$2',[p.id,em]);
 if(u)await q('UPDATE users SET google_id=$1 WHERE id=$2',[p.id,u.id]);else{u=(await q('INSERT INTO users(name,email,google_id) VALUES($1,$2,$3) RETURNING id',[p.displayName,em,p.id])).rows[0];await q('INSERT INTO study_goals(user_id) VALUES($1)',[u.id])}done(null,u)}catch(x){done(x)}}));
 auth.get('/google',passport.authenticate('google',{scope:['profile','email'],session:false}));
 auth.get('/google/callback',passport.authenticate('google',{session:false,failureRedirect:'/'}),(req,res)=>login(req,res,req.user.id,true))}
else auth.get('/google',(_q,res)=>bad(res,'Google sign-in is not configured.',501));
app.use('/api/auth',auth);
api.use((req,res,next)=>req.session.uid?next():bad(res,'Please log in.',401));
api.put('/settings',async(req,res)=>{try{const{name,goal,dark}=req.body,g=Number(goal);if(!name?.trim()||!(g>=0.5&&g<=16))return bad(res,'Enter a valid name and goal (0.5–16 hours).');
 await q('UPDATE users SET name=$1,dark=$2 WHERE id=$3',[name.trim().slice(0,60),!!dark,req.session.uid]);await q('INSERT INTO study_goals(user_id,hours) VALUES($1,$2) ON CONFLICT(user_id) DO UPDATE SET hours=$2',[req.session.uid,g]);res.json(await me(req.session.uid))}catch(x){bad(res,'Could not save settings.')}});
api.put('/settings/password',async(req,res)=>{try{const{current='',password=''}=req.body,{rows:[u]}=await q('SELECT password_hash FROM users WHERE id=$1',[req.session.uid]);
 if(password.length<8)return bad(res,'New password must be at least 8 characters.');if(u.password_hash&&!await bcrypt.compare(current,u.password_hash))return bad(res,'Current password is incorrect.');
 await q('UPDATE users SET password_hash=$1 WHERE id=$2',[await bcrypt.hash(password,12),req.session.uid]);res.json({ok:true})}catch(x){bad(res,'Could not change password.')}});
// Every row is scoped by user_id taken from the session — never from the request.
const RES={tasks:{t:'tasks',cols:['title','description','subject','due_date','priority','done','done_on'],req:['title','due_date']},
 timetable:{t:'timetable_entries',cols:['day','subject','topic','start_time','end_time'],req:['day','subject','start_time','end_time']},
 exams:{t:'exams',cols:['name','subject','exam_date','topics','status'],req:['name','exam_date']},
 sessions:{t:'focus_sessions',cols:['minutes','mode','started_on'],req:['minutes']}};
for(const[p,{t,cols,req}]of Object.entries(RES)){const pick=b=>Object.fromEntries(cols.filter(c=>b[c]!==undefined).map(c=>[c,b[c]===''?null:b[c]]));
 api.get('/'+p,async(r,s)=>s.json((await q(`SELECT * FROM ${t} WHERE user_id=$1 ORDER BY id`,[r.session.uid])).rows));
 api.post('/'+p,async(r,s)=>{try{const o=pick(r.body);if(req.some(c=>o[c]==null))return bad(s,'Please fill in all required fields.');const k=Object.keys(o);
  s.status(201).json((await q(`INSERT INTO ${t}(user_id,${k}) VALUES($1,${k.map((_,i)=>'$'+(i+2))}) RETURNING *`,[r.session.uid,...k.map(c=>o[c])])).rows[0])}catch(x){bad(s,'Invalid data.')}});
 api.put('/'+p+'/:id',async(r,s)=>{try{const o=pick(r.body),k=Object.keys(o);if(!k.length)return bad(s,'Nothing to update.');
  const{rows:[x]}=await q(`UPDATE ${t} SET ${k.map((c,i)=>`${c}=$${i+3}`)} WHERE id=$1 AND user_id=$2 RETURNING *`,[r.params.id,r.session.uid,...k.map(c=>o[c])]);x?s.json(x):bad(s,'Not found.',404)}catch(e){bad(s,'Invalid data.')}});
 api.delete('/'+p+'/:id',async(r,s)=>{try{const n=await q(`DELETE FROM ${t} WHERE id=$1 AND user_id=$2`,[r.params.id,r.session.uid]);n.rowCount?s.json({ok:true}):bad(s,'Not found.',404)}catch(e){bad(s,'Invalid request.')}})}
app.use('/api',api);
const dist=path.join(__dirname,'client/dist');app.use(express.static(dist));app.get('*',(_q,res,n)=>res.sendFile(path.join(dist,'index.html'),e=>e&&n()));
app.listen(process.env.PORT||3000,()=>console.log('StudyBloom API on :'+(process.env.PORT||3000)));
