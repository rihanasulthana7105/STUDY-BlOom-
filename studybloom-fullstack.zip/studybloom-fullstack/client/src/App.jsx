import {useState,useEffect,useCallback,useRef} from 'react';import {api} from './api';
const SUBJ=['Maths','Science','English','History','Computer','Other'],DAYS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const iso=d=>{const x=new Date(d);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')},today=()=>iso(new Date());
const daysTo=d=>Math.ceil((new Date(d+'T00:00')-new Date(today()+'T00:00'))/864e5);
const NAV=[['dashboard','🏠','Dashboard'],['tasks','✅','My Tasks'],['focus','⏱️','Focus Mode'],['timetable','🗓️','Timetable'],['exams','📝','Exam Planner'],['progress','📈','My Progress'],['settings','⚙️','Settings']];
export default function App(){
 const [me,setMe]=useState(undefined),[screen,setScreen]=useState(new URLSearchParams(location.search).get('reset')?'reset':'home');
 useEffect(()=>{api('/auth/me').then(setMe).catch(()=>setMe(null))},[]);
 useEffect(()=>{document.documentElement.dataset.theme=me?.dark?'dark':'light'},[me]);
 if(me===undefined)return <p className="auth">Loading…</p>;
 if(!me)return screen==='home'?<Landing go={setScreen}/>:<Auth mode={screen} go={setScreen} onDone={setMe}/>;
 return <Shell me={me} setMe={setMe}/>}
function Landing({go}){return <div className="land fade"><div className="nav"><div className="logo">🌸 Study<b>Bloom</b></div><button className="btn o s" onClick={()=>go('login')}>Login</button></div>
 <section className="hero"><div><h1>Study<span style={{color:'var(--lavd)'}}>Bloom</span></h1><p className="tag">Grow Your Knowledge, One Day at a Time. 💜</p><p>Your all-in-one smart study planner — tasks, timetable, focus timer, exams and progress in one place.</p>
 <div className="row" style={{justifyContent:'flex-start'}}><button className="btn" onClick={()=>go('signup')}>Get Started →</button><button className="btn o" onClick={()=>go('login')}>Login</button></div></div><div style={{fontSize:'6rem',textAlign:'center'}}>📚🪴✏️</div></section>
 <div className="grid g4">{[['✅','Tasks'],['🗓️','Timetable'],['⏱️','Focus Mode'],['📝','Exams'],['📈','Progress']].map(f=><div key={f[1]} className="card feat"><div className="i">{f[0]}</div><h3>{f[1]}</h3></div>)}</div></div>}
function Auth({mode,go,onDone}){
 const [f,setF]=useState({}),[err,setErr]=useState(''),[info,setInfo]=useState(''),[busy,setBusy]=useState(false),set=k=>e=>setF({...f,[k]:e.target.value});
 const titles={login:'Welcome back',signup:'Create your account',forgot:'Forgot password',reset:'Choose a new password'};
 const sub=async e=>{e.preventDefault();setErr('');setBusy(true);try{
  if(mode==='forgot'){await api('/auth/forgot','POST',f);setInfo('If that email exists, a reset link is on its way.')}
  else if(mode==='reset'){await api('/auth/reset','POST',{token:new URLSearchParams(location.search).get('reset'),password:f.password});history.replaceState(null,'','/');setInfo('Password updated — you can log in now.');go('login')}
  else onDone(await api('/auth/'+mode,'POST',f))}catch(x){setErr(x.message)}setBusy(false)};
 return <div className="auth fade card"><div className="logo" style={{textAlign:'center'}}>🌸 Study<b>Bloom</b></div><h2 style={{textAlign:'center'}}>{titles[mode]}</h2>
 <form onSubmit={sub}>{mode==='signup'&&<><label>Name</label><input required value={f.name||''} onChange={set('name')}/></>}
 {mode!=='reset'&&<><label>Email</label><input type="email" required value={f.email||''} onChange={set('email')}/></>}
 {mode!=='forgot'&&<><label>Password</label><input type="password" minLength={8} required value={f.password||''} onChange={set('password')} placeholder="At least 8 characters"/></>}
 {err&&<div className="err">{err}</div>}{info&&<div style={{color:'var(--mintd)'}}>{info}</div>}<br/><button className="btn" style={{width:'100%'}} disabled={busy}>{busy?'Please wait…':'Continue'}</button></form>
 {mode!=='forgot'&&mode!=='reset'&&<a className="btn o" style={{display:'block',textAlign:'center',marginTop:'.6rem'}} href="/api/auth/google">Continue with Google</a>}
 <p style={{textAlign:'center',fontSize:'.9em'}}>{mode==='login'&&<><a href="#" onClick={e=>{e.preventDefault();go('forgot')}}>Forgot password?</a> · </>}<a href="#" onClick={e=>{e.preventDefault();go(mode==='login'?'signup':'login')}}>{mode==='login'?'Sign up':'Back to login'}</a></p></div>}
function Shell({me,setMe}){
 const [page,setPage]=useState('dashboard'),[d,setD]=useState(null),[err,setErr]=useState('');
 const load=useCallback(async()=>{try{const r=await Promise.all(['tasks','timetable','exams','sessions'].map(k=>api('/'+k)));setD({tasks:r[0],timetable:r[1],exams:r[2],sessions:r[3]})}catch(x){setErr(x.message)}},[]);
 useEffect(()=>{load()},[load]);
 const crud=k=>({add:async b=>{await api('/'+k,'POST',b);await load()},upd:async(id,b)=>{await api('/'+k+'/'+id,'PUT',b);await load()},del:async id=>{await api('/'+k+'/'+id,'DELETE');await load()}});
 const logout=async()=>{await api('/auth/logout','POST');setMe(null)};
 const V={dashboard:Dash,tasks:Tasks,focus:Focus,timetable:Timetable,exams:Exams,progress:Progress,settings:Settings}[page];
 return <div className="app"><nav className="side"><div className="logo">🌸 Study<b>Bloom</b></div>{NAV.map(n=><a key={n[0]} href="#" className={n[0]===page?'on':''} onClick={e=>{e.preventDefault();setPage(n[0])}}>{n[1]} {n[2]}</a>)}<a href="#" style={{marginTop:'auto'}} onClick={e=>{e.preventDefault();logout()}}>🚪 Logout</a></nav>
 <main className="main fade">{err?<p className="err">{err}</p>:!d?<p>Loading your data…</p>:<V me={me} setMe={setMe} d={d} crud={crud} go={setPage} logout={logout}/>}</main></div>}
function Form({fields,init={},onSubmit,label,onCancel}){
 const defs=Object.fromEntries(fields.filter(f=>f.opts).map(f=>[f.k,f.opts[0]])),[v,setV]=useState({...defs,...init}),[err,setErr]=useState('');
 const sub=async e=>{e.preventDefault();try{setErr('');await onSubmit(v);if(!onCancel)setV(defs)}catch(x){setErr(x.message)}};
 return <form onSubmit={sub}><div className="grid g4">{fields.map(f=><div key={f.k}><label>{f.l}</label>{f.opts?<select value={v[f.k]} onChange={e=>setV({...v,[f.k]:e.target.value})}>{f.opts.map(o=><option key={o}>{o}</option>)}</select>:
  <input type={f.type||'text'} required={f.req} maxLength={f.type?undefined:120} value={v[f.k]??''} onChange={e=>setV({...v,[f.k]:e.target.value})}/>}</div>)}</div>{err&&<div className="err">{err}</div>}<br/><button className="btn">{label}</button> {onCancel&&<button type="button" className="btn o" onClick={onCancel}>Cancel</button>}</form>}
function Dash({me,d,go}){const t=d.tasks,dn=t.filter(x=>x.done).length,pct=t.length?Math.round(dn/t.length*100):0,hrs=d.sessions.filter(s=>s.started_on===today()).reduce((a,s)=>a+s.minutes,0)/60;
 return <><div className="row"><h1>Hello, {me.name}! 👋</h1><b>{new Date().toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short',year:'numeric'})}</b></div>
 <div className="card"><b>Daily Study Goal</b><span style={{float:'right'}}>{hrs.toFixed(1)} / {me.goal} hours</span><div className="bar" style={{marginTop:'.6rem'}}><i style={{width:Math.min(100,hrs/me.goal*100)+'%'}}/></div></div><br/>
 <div className="grid g4"><div className="card stat"><b>{t.length}</b>Total Tasks</div><div className="card stat"><b>{dn}</b>Completed</div><div className="card stat"><b>{t.length-dn}</b>Pending</div><div className="card stat"><b>{d.exams.filter(e=>daysTo(e.exam_date)>=0).length}</b>Upcoming Exams</div></div><br/>
 <div className="card"><b>Study Progress</b><div className="bar" style={{margin:'.6rem 0'}}><i style={{width:pct+'%'}}/></div>{pct}% of tasks done</div><br/>
 <div className="grid g4">{NAV.slice(1,6).map(n=><a key={n[0]} href="#" className="card feat" onClick={e=>{e.preventDefault();go(n[0])}}><div className="i">{n[1]}</div><b>{n[2]}</b></a>)}</div></>}
function Tasks({d,crud}){const c=crud('tasks'),[edit,setEdit]=useState(null),[fl,setFl]=useState('all');
 const F=[{k:'title',l:'Title',req:1},{k:'description',l:'Description'},{k:'subject',l:'Subject',opts:SUBJ},{k:'due_date',l:'Due date',type:'date',req:1},{k:'priority',l:'Priority',opts:['Low','Medium','High']}];
 const ls=d.tasks.filter(t=>fl==='all'||(fl==='pending'&&!t.done)||(fl==='completed'&&t.done)||t.subject===fl);
 return <><h1>My Tasks</h1><div className="card"><Form key={edit?.id||'new'} fields={F} init={edit||{}} label={edit?'Update task':'Add task'} onCancel={edit&&(()=>setEdit(null))} onSubmit={async v=>{edit?await c.upd(edit.id,v):await c.add(v);setEdit(null)}}/></div><br/>
 <select style={{maxWidth:220}} value={fl} onChange={e=>setFl(e.target.value)}>{['all','pending','completed',...SUBJ].map(x=><option key={x}>{x}</option>)}</select>
 <div className="card" style={{marginTop:'.8rem'}}>{ls.length?ls.map(t=><div key={t.id} className={'task '+(t.done?'done':'')}><input type="checkbox" checked={t.done} onChange={()=>c.upd(t.id,{done:!t.done,done_on:t.done?null:today()})}/>
 <div style={{flex:1}}><b className="tt">{t.title}</b> <span className={'chip '+t.priority}>{t.priority}</span> <span className="chip">{t.subject}</span><br/><small>{t.description} · due {t.due_date}</small></div>
 <button className="btn s o" onClick={()=>{setEdit(t);scrollTo(0,0)}}>Edit</button> <button className="btn s d" onClick={()=>c.del(t.id)}>Delete</button></div>):<p style={{color:'var(--mut)'}}>No tasks here yet 🌱</p>}</div></>}
function Focus({d,crud}){
 const [m,setM]=useState({name:'Focus',len:25}),[left,setLeft]=useState(1500),[run,setRun]=useState(false),[cu,setCu]=useState(''),c=crud('sessions'),ref=useRef(null);
 const pick=(name,len)=>{if(!(len>=1&&len<=180))return;setRun(false);setM({name,len});setLeft(len*60)};
 useEffect(()=>{if(!run)return;ref.current=setInterval(()=>setLeft(l=>l-1),1000);return()=>clearInterval(ref.current)},[run]);
 useEffect(()=>{if(left<=0){setRun(false);setLeft(m.len*60);if(!m.name.includes('Break'))c.add({minutes:m.len,mode:m.name})}},[left]);
 const ts=d.sessions.filter(s=>s.started_on===today());
 return <><h1>Focus Mode</h1><div className="card"><div className="row" style={{justifyContent:'center'}}>{[['Focus',25],['Short Break',5],['Long Break',15]].map(x=><button key={x[0]} className={'btn s '+(m.name===x[0]?'':'o')} onClick={()=>pick(...x)}>{x[0]} {x[1]}m</button>)}
 <input type="number" min="1" max="180" placeholder="Custom min" style={{width:120}} value={cu} onChange={e=>setCu(e.target.value)}/><button className="btn s o" onClick={()=>pick('Custom',+cu)}>Set</button></div>
 <p style={{textAlign:'center'}}><span className="chip">Current: {m.name}</span></p><div className="timer">{String(Math.floor(left/60)).padStart(2,'0')}:{String(left%60).padStart(2,'0')}</div>
 <div className="row" style={{justifyContent:'center'}}><button className="btn" onClick={()=>setRun(!run)}>{run?'Pause':'Start'}</button><button className="btn o" onClick={()=>{setRun(false);setLeft(m.len*60)}}>Reset</button></div></div><br/>
 <div className="grid g4"><div className="card stat"><b>{ts.length}</b>Sessions today</div><div className="card stat"><b>{d.sessions.length}</b>Total sessions</div><div className="card stat"><b>{Math.round(d.sessions.reduce((a,s)=>a+s.minutes,0))}</b>Total minutes</div></div><br/>
 <div className="card"><b>History</b>{d.sessions.slice(-6).reverse().map(s=><div key={s.id} className="row"><span>🌿 {s.minutes} min</span><small>{s.started_on}</small></div>)}</div></>}
function Timetable({d,crud}){const c=crud('timetable'),[edit,setEdit]=useState(null);
 const F=[{k:'day',l:'Day',opts:DAYS},{k:'subject',l:'Subject',req:1},{k:'topic',l:'Topic'},{k:'start_time',l:'Start',type:'time',req:1},{k:'end_time',l:'End',type:'time',req:1}];
 const chk=v=>{if(v.end_time<=v.start_time)throw new Error('End time must be after start time.')};
 return <><h1>Study Timetable</h1><div className="card"><Form key={edit?.id||'new'} fields={F} init={edit||{}} label={edit?'Update entry':'Add entry'} onCancel={edit&&(()=>setEdit(null))} onSubmit={async v=>{chk(v);edit?await c.upd(edit.id,v):await c.add(v);setEdit(null)}}/></div><br/>
 <div className="week">{DAYS.map(day=><div key={day} className="card" style={{padding:'.6rem'}}><b>{day.slice(0,3)}</b>{d.timetable.filter(x=>x.day===day).sort((a,b)=>a.start_time.localeCompare(b.start_time)).map(x=><div key={x.id} className="slot"><b>{x.subject}</b><br/>{x.topic}<br/><small>{x.start_time}–{x.end_time}</small><br/><a href="#" onClick={e=>{e.preventDefault();setEdit(x);scrollTo(0,0)}}>✏️</a> <a href="#" onClick={e=>{e.preventDefault();c.del(x.id)}}>🗑️</a></div>)}</div>)}</div></>}
function Exams({d,crud}){const c=crud('exams'),[edit,setEdit]=useState(null);
 const F=[{k:'name',l:'Exam name',req:1},{k:'subject',l:'Subject',opts:SUBJ},{k:'exam_date',l:'Date',type:'date',req:1},{k:'topics',l:'Syllabus / topics'},{k:'status',l:'Preparation',opts:['Not started','In progress','Ready']}];
 return <><h1>Exam Planner</h1><div className="card"><Form key={edit?.id||'new'} fields={F} init={edit||{}} label={edit?'Update exam':'Add exam'} onCancel={edit&&(()=>setEdit(null))} onSubmit={async v=>{edit?await c.upd(edit.id,v):await c.add(v);setEdit(null)}}/></div><br/>
 <div className="grid g2">{[...d.exams].sort((a,b)=>a.exam_date.localeCompare(b.exam_date)).map(x=>{const n=daysTo(x.exam_date);return <div key={x.id} className="card"><div className="row"><b>{x.name}</b><span className="chip">{x.subject}</span></div>
 <div style={{fontSize:'1.6rem',fontWeight:800,color:'var(--lavd)'}}>{n<0?'Finished':n===0?'Today!':n+' days left'}</div><small>{x.exam_date} · {x.status}</small><p>{x.topics}</p><button className="btn s o" onClick={()=>{setEdit(x);scrollTo(0,0)}}>Edit</button> <button className="btn s d" onClick={()=>c.del(x.id)}>Delete</button></div>})}</div></>}
function Progress({d}){const days=[...Array(7)].map((_,i)=>{const x=new Date();x.setDate(x.getDate()-6+i);return{k:iso(x),l:x.toLocaleDateString(undefined,{weekday:'short'})}});
 const dt=days.map(x=>d.tasks.filter(t=>t.done_on===x.k).length),fm=days.map(x=>d.sessions.filter(s=>s.started_on===x.k).reduce((a,s)=>a+s.minutes,0)),tm=d.sessions.reduce((a,s)=>a+s.minutes,0),wk=dt.reduce((a,b)=>a+b,0);
 const bars=(a,u)=>{const mx=Math.max(1,...a);return <div className="chart">{a.map((v,i)=><div key={i}><small>{v}{u}</small><i style={{height:v/mx*110}}/>{days[i].l}</div>)}</div>};
 const msg=wk>=5||tm>=120?'Amazing consistency — your garden is blooming! 🌸':wk>0||tm>0?'Nice start! Keep growing a little every day 🌱':'Complete a task or focus session to start growing 🌿';
 return <><h1>My Progress</h1><div className="card" style={{background:'var(--mint)'}}><b>{msg}</b></div><br/><div className="grid g4"><div className="card stat"><b>{d.sessions.length}</b>Focus sessions</div><div className="card stat"><b>{Math.floor(tm/60)}h {Math.round(tm%60)}m</b>Study time</div><div className="card stat"><b>{wk}</b>Tasks this week</div></div><br/>
 <div className="grid g2"><div className="card"><b>Daily completed tasks</b>{bars(dt,'')}</div><div className="card"><b>Weekly focus minutes</b>{bars(fm,'m')}</div></div><br/>
 <div className="card"><b>Subject-wise progress</b>{SUBJ.map(s=>{const a=d.tasks.filter(t=>t.subject===s);if(!a.length)return null;const p=Math.round(a.filter(t=>t.done).length/a.length*100);return <div key={s}><p style={{margin:'.7rem 0 .2rem'}}>{s} — {p}%</p><div className="bar"><i style={{width:p+'%'}}/></div></div>})}</div></>}
function Settings({me,setMe,logout}){const [n,setN]=useState(me.name),[g,setG]=useState(me.goal),[cur,setCur]=useState(''),[pw,setPw]=useState(''),[msg,setMsg]=useState('');
 const run=async fn=>{try{await fn();setMsg('Saved ✔')}catch(x){setMsg(x.message)}};
 const save=dark=>run(async()=>setMe(await api('/settings','PUT',{name:n,goal:g,dark})));
 return <><h1>Settings</h1>{msg&&<p className="chip">{msg}</p>}<div className="grid g2"><div className="card"><b>Profile</b><label>Name</label><input value={n} onChange={e=>setN(e.target.value)}/><label>Daily study goal (hours)</label><input type="number" min="0.5" max="16" step="0.5" value={g} onChange={e=>setG(e.target.value)}/><br/><br/><button className="btn" onClick={()=>save(me.dark)}>Save</button></div>
 <div className="card"><b>Change password</b><label>Current password</label><input type="password" value={cur} onChange={e=>setCur(e.target.value)}/><label>New password</label><input type="password" minLength={8} value={pw} onChange={e=>setPw(e.target.value)}/><br/><br/><button className="btn" onClick={()=>run(async()=>{await api('/settings/password','PUT',{current:cur,password:pw});setCur('');setPw('')})}>Update password</button></div>
 <div className="card"><b>Appearance</b><br/><br/><button className="btn o" onClick={()=>save(!me.dark)}>Switch to {me.dark?'light':'dark'} mode</button></div><div className="card"><b>Account</b><br/><br/><button className="btn d" onClick={logout}>Logout</button></div></div></>}
